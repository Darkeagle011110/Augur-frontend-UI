// src/components/MetricCard.js
import React from "react";
import styled from "styled-components";

const Card = styled.div`
  background-color: #fff;
  border-radius: 10px;
  padding: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  margin: 10px;
  text-align: center;
`;

const MetricTitle = styled.h3`
  font-size: 1.2rem;
  color: #333;
`;

const MetricValue = styled.p`
  font-size: 1.5rem;
  font-weight: bold;
  color: #2c3e50;
`;

const MetricCard = ({ title, value }) => (
  <Card>
    <MetricTitle>{title}</MetricTitle>
    <MetricValue>{value}</MetricValue>
  </Card>
);

export default MetricCard;
