// src/components/DistributorCard.js
import React from "react";
import styled from "styled-components";
import MetricCard from "./MetricCard";

const CardContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #f9f9f9;
  border-radius: 12px;
  margin: 20px;
  width: 280px;
  padding: 20px;
`;

const DistributorName = styled.h2`
  font-size: 1.8rem;
  color: #34495e;
  margin-bottom: 16px;
`;

const DistributorCard = ({ distributor }) => (
  <CardContainer>
    <DistributorName>{distributor.name}</DistributorName>
    <MetricCard title="Last Month" value={distributor.lastMonth} />
    <MetricCard title="Forecast" value={distributor.forecast} />
    <MetricCard title="YTD Average" value={distributor.ytdAverage} />
  </CardContainer>
);

export default DistributorCard;
