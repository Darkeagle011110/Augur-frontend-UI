// src/services/mockData.js
export const mockDistributors = [
  {
    name: "Distributor A",
    lastMonth: 5000,
    forecast: 4500,
    ytdAverage: 4800,
  },
  {
    name: "Distributor B",
    lastMonth: 3200,
    forecast: 3500,
    ytdAverage: 3300,
  },
  {
    name: "Distributor C",
    lastMonth: 7000,
    forecast: 7200,
    ytdAverage: 6800,
  },
  {
    name: "Distributor D",
    lastMonth: 6000,
    forecast: 6200,
    ytdAverage: 5900,
  },
  {
    name: "Distributor E",
    lastMonth: 4000,
    forecast: 4200,
    ytdAverage: 4300,
  },
  // Add more distributors if needed
];
