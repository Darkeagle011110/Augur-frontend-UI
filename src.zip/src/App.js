// src/App.js
import React from "react";
import styled from "styled-components";
import { mockDistributors } from "./services/mockData";
import DistributorCard from "./components/DistributorCard";
import GlobalStyles from "./styles/GlobalStyles";

const AppContainer = styled.div`
  font-family: Arial, sans-serif;
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  padding: 40px;
  background-color: #ecf0f1;
`;

const App = () => {
  return (
    <>
      <GlobalStyles />
      <AppContainer>
        {mockDistributors.map((distributor, index) => (
          <DistributorCard key={index} distributor={distributor} />
        ))}
      </AppContainer>
    </>
  );
};

export default App;
